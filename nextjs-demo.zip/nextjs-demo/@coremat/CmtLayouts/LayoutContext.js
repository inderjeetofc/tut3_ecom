import React from 'react';

//todo set initial value of LayoutContextProvider
const LayoutContext = React.createContext();

export default LayoutContext;
