import React from 'react';

//todo set initial value of SidebarThemeContext
const SidebarThemeContext = React.createContext();

export default SidebarThemeContext;
