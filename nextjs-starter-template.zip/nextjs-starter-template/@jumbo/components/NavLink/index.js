import React from 'react';

const NavLink = () => {
  return <div></div>;
};

export default NavLink;
