import { combineReducers } from 'redux';

import Common from './Common';

export default combineReducers({
  common: Common
});
